--
-- PostgreSQL database dump
--

\restrict OELnwP7JRHcTp6LjjB98ggYE7WJT7BEAfX03pa8GiUZzTeqZ3f02PuGeLosTQeJ

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: plans; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- PostgreSQL database dump complete
--

\unrestrict OELnwP7JRHcTp6LjjB98ggYE7WJT7BEAfX03pa8GiUZzTeqZ3f02PuGeLosTQeJ

